var app = require('http').createServer(handler)
var io = require('socket.io')(app)
app.listen('8088',function(){
	console.log("正在监听8088端口")
})

function handler(req,res){
	res.writeHead(200);
    res.end("你瞅啥");
}

//获取数组交集
intersect = function(arr1, arr2) {
    if(Object.prototype.toString.call(arr1) === "[object Array]" && Object.prototype.toString.call(arr2) === "[object Array]") {
        return arr1.filter(function(v){ 
            return arr2.indexOf(v)!==-1 
        }) 
    }
}

var rooms = {};		//项目组

io.on('connection',function(socket){
	var roomId;
	var user;
	/*
	*用户加入事件
	*用户需要:room(项目名),
	*	可选:id(用户唯一标实)
	*/
	socket.on('join',function(res){
		if(res.room){
			roomId = res.room;
			if(!rooms[roomId]){	//如果项目不在项目组里
				rooms[roomId] = {};
			}
			socket.join(roomId);
			if(res.id){
				user = res.id;
				if(rooms[roomId][user]){
					rooms[roomId][user].emit('edge_out',{msg:'您的账号在其他地方登陆！'});
				}else{
					rooms[roomId][user] = socket;
				}
			}
		}
	});

	/*
	*用户登陆
	*需要:id(用户唯一标实)
	*/
	socket.on('login',function(res){
		if(res.id){
			user = res.id;
			if(rooms[roomId][user]){
				rooms[roomId][user].emit('edge_out',{msg:'您的账号在其他地方登陆！'});
			}else{
				rooms[roomId][user] = socket;
				console.log('用户登陆')
			}
		}
	});
  	
  	/*
	*判断用户是否登陆
	*需要:user(要判断的用户集合 array)
	*/
  	socket.on('user_is_login',function(res){
    	if(res.user){
    		let data = [];
	        for(let i in rooms[roomId]){
	          data.push(i)
	        }
          	if(data){
            	var login_user = intersect(data,res.user);
            	socket.emit('user_is_login',{data:login_user})
            }
        }
    })

	//用户退出登陆事件
	socket.on('logout',function(){
        if(rooms[roomId][user]){
            delete rooms[roomId][user]
        }
    });

	//用户关闭事件
    socket.on('disconnect', function () {
    	if(rooms[roomId][user]){
            delete rooms[roomId][user]
        }
        // if(JSON.stringify(rooms[roomId]) == "{}"){
        // 	delete rooms[roomId]
        // }
  	});
})

//全局错误处理机制
process.on('uncaughtException', function(err) {
    //打印出错误的调用栈方便调试
    console.log(err.stack);
})