//  Created by Mingliang Chen on 15/1/16.
//  Copyright (c) 2015 Nodemedia. All rights reserved.

// var heapdump = require('heapdump');
var NMServer = require('./nm_server');
var server = new NMServer();
server.run();