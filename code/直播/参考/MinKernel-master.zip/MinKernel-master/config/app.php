<?php
# 应用配置
return [
	# 默认应用名称
	'default_m_name'=>'Home',
	# 默认控制器名称
	'default_c_name'=>'Index',
	# 默认操作名称
	'default_a_name'=>'index',
	];