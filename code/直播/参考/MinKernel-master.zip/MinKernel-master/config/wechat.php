<?php
return [
	# 微信的公众平台的appid
	'appid'=>'',
	# 微信开放平台的的appid
	'open_appid'=>'',
	# 公众号的secret
	'secret'=>'',
	# 微信公众号商户平台付key
	'pay_key'=>'',
	# 微信开放商户平台key
	'open_pay_key'=>'',
	# 微信公众商户平台商户id
	'mchid' => '',
	# 微信开放平台商户id
	'open_mchid' => '',
	#通知回调地址
	'notify_url'=>'',

];
