<?php

return [

  'host' => 'smtp.xx.com', # 邮箱的smtp服务器

  'username' => 'username', # 邮箱登录用户名
  'port' => 587, # 邮箱登录端口

  'password' => 'password', # 邮箱的授权码(一般情况下 就是邮箱的登录密码)
  'from'=>'xxxxxxx@xx.com', # 邮件的发送者地址
  'fromName'=>'Name', # 邮件的发送者名称
  'reply' => 'xxxxxxx@xx.com', # 邮件的回复地址
  'replyName' => 'Name', # 邮件的回复名称
  'cc' => 'xxxxxxx@xx.com', # 邮件的回复地址
  'bcc' => 'xxxxxxx@xx.com', # 邮件的回复地址

];