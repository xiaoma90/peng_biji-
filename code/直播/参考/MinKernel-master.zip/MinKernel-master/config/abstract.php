<?php
# 虚拟目录
return [
	# debugbar资源文件
	'resources'=>ROOT_PATH.'vendor'.DIRECTORY_SEPARATOR.'maximebf'.DIRECTORY_SEPARATOR.'debugbar'.DIRECTORY_SEPARATOR.'src'.DIRECTORY_SEPARATOR.'DebugBar',
	# 后台资源文件
	'assets'=>ROOT_PATH.'common',
];