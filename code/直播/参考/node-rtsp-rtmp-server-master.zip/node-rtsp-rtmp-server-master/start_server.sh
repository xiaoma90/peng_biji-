#!/bin/sh

sudo coffee server.coffee
